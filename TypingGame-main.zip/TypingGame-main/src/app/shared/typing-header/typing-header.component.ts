import { Component } from '@angular/core';

@Component({
  selector: 'typing-header',
  templateUrl: './typing-header.component.html',
  styleUrls: ['./typing-header.component.scss']
})
export class TypingHeaderComponent {

}
