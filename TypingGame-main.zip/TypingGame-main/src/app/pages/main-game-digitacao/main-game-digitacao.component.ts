import { Component } from '@angular/core';

@Component({
  selector: 'main-game-digitacao',
  templateUrl: './main-game-digitacao.component.html',
  styleUrls: ['./main-game-digitacao.component.scss']
})
export class MainGameDigitacaoComponent {

}
